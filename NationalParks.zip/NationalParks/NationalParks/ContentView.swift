//
//  ContentView.swift
//  NationalParks
//
//  Created by Zhewei Wu on 4/8/20.
//  Copyright © 2020 Zhewei Wu. All rights reserved.
//

import SwiftUI

struct ContentView: View {
 
    var body: some View {
        TabView {
            
            Home().tabItem {
                Image(systemName: "house")
                Text("Home")
            }
            
            ParksVisitedList().tabItem {
                Image(systemName: "heart")
                Text("Parks Visited")
            }
            
            SearchByName().tabItem {
                Image(systemName: "magnifyingglass")
                Text("Search by Name")
            }
            
            SearchByState().tabItem {
                Image(systemName: "magnifyingglass")
                Text("Search by State")
            }
        
        } // End of TabView
        .font(.headline)
        .imageScale(.medium)
        .font(Font.title.weight(.regular))
        
    } // End of Body
} // End of ContentView Struct

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
