//
//  Audio.swift
//  NationalParks
//
//  Created by Zhewei Wu on 4/14/20.
//  Copyright © 2020 Zhewei Wu. All rights reserved.
//

import Foundation
import CoreData
 
 
// ❎ CoreData Audio entity public class
public class Audio: NSManagedObject, Identifiable {
 
    @NSManaged public var voiceRecording: Data?
    @NSManaged public var parkVisit: ParkVisit?
}
