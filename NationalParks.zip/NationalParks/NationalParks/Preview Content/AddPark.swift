//
//  AddPark.swift
//  NationalParks
//
//  Created by Zhewei Wu on 4/14/20.
//  Copyright © 2020 Zhewei Wu. All rights reserved.
//

import SwiftUI
import Speech
import AVFoundation


struct AddPark: View {
    
       // Enable this View to be dismissed to go back when the Save button is tapped
       @Environment(\.presentationMode) var presentationMode
      
       // ❎ CoreData managedObjectContext reference
       @Environment(\.managedObjectContext) var managedObjectContext
       
       @State private var fullName = ""
       @State private var states = ""
       @State private var speechToTextNotes = ""
       @State private var dateVisited = Date()
       @State private var ratingIndex = 0
      
       @State private var showImagePicker = false
       @State private var photoImageData: Data? = nil
       @State private var audioData: Data? = nil
       @State private var photoTakeOrPickIndex = 0
      
       let ratingList = ["Outstanding", "Excellent", "Great", "Very Good", "Good", "Satisfactory", "Fair", "Poor"]
       var addPhotoOption = ["Camera", "Photo Library"]
       
       var dateVisitedRange: ClosedRange<Date> {
           // Set minimum date to 30 years earlier than the current year
           let minDate = Calendar.current.date(byAdding: .year, value: -30, to: Date())!
          
           // Set maximum date to 4 years later than the current year
           let maxDate = Calendar.current.date(byAdding: .year, value: 4, to: Date())!
           return minDate...maxDate
       }
    
       @State private var recordingVoiceIMG = false
       @State private var recording = false
     
       @State private var showAddedMessage = false
       @State private var showErrorMessage = false
    
       var body: some View {
           Form {
               Section(header: Text("National Park Full Name")) {
                   TextField("Enter national park full name", text: $fullName)
               }
            
               Section(header: Text("National Park State Names")) {
                   TextField("Enter national park's state name", text: $states)
               }
            
               Section(header: Text("Date Visited National Park")) {
                   DatePicker(
                       selection: $dateVisited,
                       in: dateVisitedRange,
                       displayedComponents: .date,
                       label: { Text("Date Visited") }
                   )
               }
            
               Section(header: Text("My Rating of the National Park")) {
                   Picker("", selection: $ratingIndex) {
                       ForEach(0 ..< ratingList.count, id: \.self) {
                           Text(self.ratingList[$0])
                       }
                   }
                   .pickerStyle(WheelPickerStyle())
               }
            
               Section(header: Text("Take Notes by Recording Your Voice")) {
                  Button(action: {
                       self.firstMicrophoneTapped()
                   }) {
                       firstMicrophoneLabel
                   }
               }
            
               Section(header: Text("Take Notes by Convering Your Speech to Text")) {
                 VStack {
                     Button(action: {
                         self.secondMicrophoneTapped()
                     }) {
                         secondMicrophoneLabel
                     }
                     .padding()
                     Text(speechToTextNotes)
                         .multilineTextAlignment(.center)
                         // This enables the text to wrap around on multiple lines
                         .fixedSize(horizontal: false, vertical: true)
                 }
                 .onDisappear() {
                     self.speechToTextNotes = ""
                 }
               }
            
               Section(header: Text("Add National Park Visit Photo")) {
                   VStack {
                       Picker("Take or Pick Photo", selection: $photoTakeOrPickIndex) {
                           ForEach(0 ..< addPhotoOption.count, id: \.self) {
                               Text(self.addPhotoOption[$0])
                           }
                       }
                       .pickerStyle(SegmentedPickerStyle())
                       .padding()
                       
                       Button(action: {
                           self.showImagePicker = true
                       }) {
                           Text("Get Photo")
                               .padding()
                       }
                   }   // End of VStack
               }
            
               Section(header: Text("National Park Visit Photo")) {
                   visitPhoto
                       .resizable()
                       .aspectRatio(contentMode: .fit)
                       .frame(width: 100.0, height: 100.0)
               }
           }   // End of Form
           .disableAutocorrection(true)
           .autocapitalization(.words)
           .alert(isPresented: $showAddedMessage, content: { self.addedMessageAlert })
           .alert(isPresented: $showErrorMessage, content: { self.errorMessageAlert })
           .navigationBarTitle(Text("Add New National Park Visit"), displayMode: .inline)
           .navigationBarItems(trailing:
               Button(action: {
                  
                    // Dismiss this View and go back
                    if self.fullName.isEmpty || self.states.isEmpty  {
                        self.showErrorMessage = true
                    }else{
                        self.showAddedMessage = true
                        self.saveNewPark()
                        self.presentationMode.wrappedValue.dismiss()
                    }
               }) {
                   Text("Save")
               })
           .sheet(isPresented: self.$showImagePicker) {
               /*
                🔴 We pass $showImagePicker and $photoImageData with $ sign into PhotoCaptureView
                so that PhotoCaptureView can change them. The @Binding keywork in PhotoCaptureView
                indicates that the input parameter passed is changeable (mutable).
                */
               PhotoCaptureView(showImagePicker: self.$showImagePicker,
                                photoImageData: self.$photoImageData,
                                cameraOrLibrary: self.addPhotoOption[self.photoTakeOrPickIndex])
           }
       }   // End of body
    
    
       var visitPhoto: Image {
          
           if let img = self.photoImageData {
               let imgD = photoImageFromBinaryData(binaryData: img)
               return imgD
           } else {
               return Image("DefaultParkPhoto")
           }
        }
       
    
        /*
        ---------------------
        MARK: - Save New Park
        ---------------------
        */
        func saveNewPark() {
             
            // Input Data Validation
            if self.fullName.isEmpty || self.states.isEmpty {return}
                  
            // Create an instance of DateFormatter
            let dateFormatter = DateFormatter()
                    
            // Set the date format to yyyy-MM-dd
            dateFormatter.dateFormat = "yyyy-MM-dd"
            dateFormatter.locale = Locale(identifier: "en_US")
                    
            // Convert date String from "yyyy-MM-dd" to Date struct
            let releaseDateString = dateFormatter.string(from: self.dateVisited)
                
            let dateStruct = dateFormatter.date(from: releaseDateString)
                    
            // Create a new instance of DateFormatter
            let newDateFormatter = DateFormatter()
                    
            newDateFormatter.locale = Locale(identifier: "en_US")
            newDateFormatter.dateStyle = .long
            newDateFormatter.timeStyle = .none
                    
            // Obtain newly formatted Date String
            let dateWithNewFormat = newDateFormatter.string(from: dateStruct!)
                  
            let currentDateAndTime = Date()
            let currentdateFormatter = DateFormatter()
            currentdateFormatter.dateFormat = "yyyy-MM-dd' at 'HH:mm:ss"
            _ = currentdateFormatter.string(from: currentDateAndTime)
            
            /*
            =====================================================
            Create an instance of the Song Entity and dress it up
            =====================================================
            */

            // ❎ Create a new Park entity in CoreData managedObjectContext
            let aPark = ParkVisit(context: self.managedObjectContext)
            let location = currentLocation()

            // ❎ Dress up the new Park entity
            aPark.fullName = self.fullName
            aPark.states = self.states
            aPark.speechToTextNotes = self.speechToTextNotes
            aPark.dateVisited = dateWithNewFormat
            aPark.rating = self.ratingList[ratingIndex]


            /*
            ==========================================================
            Create an instance of the Photo and Audio Entity and dress it up
            ==========================================================
            */
            // ❎ Create a new Photo entity in CoreData managedObjectContext
            let aPhoto = Photo(context: self.managedObjectContext)
            
            
            aPhoto.latitude = NSNumber(value: location.latitude)
            aPhoto.longitude = NSNumber(value: location.longitude)
            
            // ❎ Dress up the new Thumbnail entity
            if let imageData = self.photoImageData {
                aPhoto.nationalParkPhoto = imageData
            } else {
                 // Obtain the default photo from main bundle
                let defaultImage = Bundle.main.url(forResource: "DefaultParkPhoto", withExtension: "jpg", subdirectory: "NationalParkPhotos")
                           
                do {
                    // Try to get the photo image data from imageUrl
                    aPhoto.nationalParkPhoto = try Data(contentsOf: defaultImage!, options: NSData.ReadingOptions.mappedIfSafe)
                } catch {
                    fatalError("DefaultParkImage.png file is not found in the main bundle!")
                }
            }
                  
            let aAudio = Audio(context: self.managedObjectContext)
            let filename = self.fullName + ".m4a"
            let voiceMemoFileUrl = documentDirectory.appendingPathComponent(filename)
                
            do {
                // Try to get the photo image data from imageUrl
                audioData = try Data(contentsOf: voiceMemoFileUrl, options: NSData.ReadingOptions.mappedIfSafe)
                aAudio.voiceRecording = self.audioData
                
            }catch{
                print("Unable to found in the documentDirectory!")
            }
                  
            /*
            ==============================
            Establish Entity Relationships
            ==============================
            */
            aPark.audio = aAudio
            aAudio.parkVisit = aPark
            aPark.photo = aPhoto
            aPhoto.parkVisit = aPark
            

            
            /*
            ==================================
            Save Changes to Core Data Database
            ==================================
            */

            // ❎ CoreData Save operation
            do {
                try self.managedObjectContext.save()
            } catch {
                return
            }
        }
    
        var addedMessageAlert: Alert {
            Alert(title: Text("New Visit Saved!"),
                message: Text("Your new national park visit is successfully saved in database!"),
                dismissButton: .default(Text("OK")) )
        }
    
        var errorMessageAlert: Alert {
            Alert(title: Text("New Visit Unsaved!"),
                message: Text("Your new national park visit is unsaved in database!"),
                dismissButton: .default(Text("OK")) )
        }
    
        //-------------------------recording function----------------------//
         /*
         ------------------------
         MARK: - Supporting Views
         ------------------------
         */
    
         var firstMicrophoneLabel: some View {
             VStack {
                 Image(systemName: recordingVoiceIMG ? "mic.fill" : "mic.slash.fill")
                     .imageScale(.large)
                     .font(Font.title.weight(.medium))
                     .foregroundColor(.blue)
                     .padding()
                 Text(recordingVoiceIMG ? "Recording your voice... Tap to Stop!" : "Start Recording!")
                     .multilineTextAlignment(.center)
             }
         }
    
    
        /*
        -------------------------
        MARK: - Microphone Tapped
        -------------------------
        */
        func firstMicrophoneTapped() {
            if audioRecorder == nil {
                self.recordingVoiceIMG = true
                startRecording()
            } else {
                self.recordingVoiceIMG = false
                finishRecording()
            }
        }
    
    
         /*
         ----------------------------------
         MARK: - Start Voice Memo Recording
         ----------------------------------
         */
         func startRecording() {
            
             let filename =  self.fullName + ".m4a"
             let audioFilenameUrl = documentDirectory.appendingPathComponent(filename)
             
             let settings = [
                 AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
                 AVSampleRateKey: 12000,
                 AVNumberOfChannelsKey: 1,
                 AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
             ]
        
             do {
                 audioRecorder = try AVAudioRecorder(url: audioFilenameUrl, settings: settings)
                 audioRecorder.record()
             } catch {
                 finishRecording()
             }
         }
    
        /*
        -----------------------------------
        MARK: - Finish Voice Memo Recording
        -----------------------------------
        */
        func finishRecording() {
            audioRecorder.stop()
            audioRecorder = nil
            self.recordingVoiceIMG = false
        }
    
    
        //-------------------------speech to note function----------------------//
    
    
        /*
        -----------------------
        MARK: - Supporting View
        -----------------------
        */
        var secondMicrophoneLabel: some View {
            VStack {
                Image(systemName: recording ? "mic.fill" : "mic.slash.fill")
                    .imageScale(.large)
                    .font(Font.title.weight(.medium))
                    .foregroundColor(.blue)
                Text(recording ? "Recording your voice... Tap to Stop!" : "Convert Speech to Text!")
                    .padding()
                    .multilineTextAlignment(.center)
            }
        }
        /*
        -------------------------
        MARK: - Microphone Tapped
        -------------------------
        */
        func secondMicrophoneTapped() {
            if recording {
                cancelRecording()
                self.recording = false
            } else {
                self.recording = true
                recordAndRecognizeSpeech()
            }
        }
        /*
        ------------------------
        MARK: - Cancel Recording
        ------------------------
        */
        func cancelRecording() {
            request.endAudio()
            audioEngine.inputNode.removeTap(onBus: 0)
            audioEngine.stop()
            recognitionTask?.finish()
        }
        /*
        ----------------------------------------------
        MARK: - Record Audio and Transcribe it to Text
        ----------------------------------------------
        */
        func recordAndRecognizeSpeech() {
            //--------------------
            // Set up Audio Buffer
            //--------------------
            let node = audioEngine.inputNode
            let recordingFormat = node.outputFormat(forBus: 0)
            node.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { buffer, _ in
                request.append(buffer)
            }
           
            //---------------------
            // Prepare Audio Engine
            //---------------------
            audioEngine.prepare()
           
            //-------------------
            // Start Audio Engine
            //-------------------
            do {
                try audioEngine.start()
            } catch {
                print("Unable to start Audio Engine!")
                return
            }
           
            //-------------------------------
            // Convert recorded voice to text
            //-------------------------------
            recognitionTask = speechRecognizer.recognitionTask(with: request, resultHandler: { result, error in
               
                if result != nil {  // check to see if result is empty (i.e. no speech found)
                    if let resultObtained = result {
                        let bestString = resultObtained.bestTranscription.formattedString
                        self.speechToTextNotes = bestString
                        
                    } else if let error = error {
                        print("Transcription failed, but will continue listening and try to transcribe. See \(error)")
                    }
                }
            })
        }

}

struct AddPark_Previews: PreviewProvider {
    static var previews: some View {
        AddPark()
    }
}

