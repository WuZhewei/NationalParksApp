//
//  ParksVisitedList.swift
//  NationalParks
//
//  Created by Zhewei Wu on 4/14/20.
//  Copyright © 2020 Zhewei Wu. All rights reserved.
//


import SwiftUI
import AVFoundation

struct ParksVisitedList: View {
    
    // ❎ CoreData managedObjectContext reference
     @Environment(\.managedObjectContext) var managedObjectContext
    
     // ❎ CoreData FetchRequest returning all Song entities in the database
     @FetchRequest(fetchRequest: ParkVisit.allParksFetchRequest()) var allParks: FetchedResults<ParkVisit>
    
     // ❎ Refresh this view upon notification that the managedObjectContext completed a save.
     // Upon refresh, @FetchRequest is re-executed fetching all Song entities with all the changes.
     @EnvironmentObject var userData: UserData
   
    var body: some View {
        NavigationView {
            if self.allParks.count == 0 {
               
                // If the database is empty, ask the user to populate it.
                Button(action: {
                    self.addInitialContentToDatabase()
                }) {
                    HStack {
                        Image(systemName: "gear")
                            .imageScale(.medium)
                            .font(Font.title.weight(.regular))
                            .foregroundColor(.blue)
                        Text("Populate Database")
                    }
                }
            }
 
            List {
                /*
                 Each NSManagedObject has internally assigned unique ObjectIdentifier
                 used by ForEach to display the parks in a dynamic scrollable list.
                 */
                ForEach(self.allParks) { aPark in
                    NavigationLink(destination: ParksVisitedDetails(park: aPark)) {
                        ParksVisitedItem(park: aPark)
                    }
                }
                .onDelete(perform: delete)
               
            }   // End of List
            .navigationBarTitle(Text("National Parks Visited"), displayMode: .inline)
           
            // Place the Edit button on left and Add (+) button on right of the navigation bar
            .navigationBarItems(leading: EditButton(), trailing:
                NavigationLink(destination: AddPark()) {
                    Image(systemName: "plus")
                })
           
        }   // End of NavigationView
    }
   
    /*
     ----------------------------
     MARK: - Delete Selected Park
     ----------------------------
     */
    func delete(at offsets: IndexSet) {
       
        let parkToDelete = self.allParks[offsets.first!]
       
        // ❎ CoreData Delete operation
        self.managedObjectContext.delete(parkToDelete)
 
        // ❎ CoreData Save operation
        do {
          try self.managedObjectContext.save()
        } catch {
          print("Unable to delete selected park!")
        }
    }
   
    /*
     ---------------------------------------
     MARK: - Add Initial Content to Database
     ---------------------------------------
     */
    func addInitialContentToDatabase() {
       
        // This public function is given in LoadInitialContentData.swift
        loadInitialDatabaseContent()
       
        // listOfMusicAlbums = [Album]() is now available
       
        for park in listOfNationalParks {
            
            // Data Formatter
            let dateFormatter = DateFormatter()
            
            // Set the date format to yyyy-MM-dd
            dateFormatter.dateFormat = "yyyy-MM-dd"
            dateFormatter.locale = Locale(identifier: "en_US")
            
            // Convert date String from "yyyy-MM-dd" to Date struct
            let dateStruct = dateFormatter.date(from: park.dateVisited)
            
            // Create a new instance of DateFormatter
            let newDateFormatter = DateFormatter()
            
            newDateFormatter.locale = Locale(identifier: "en_US")
            newDateFormatter.dateStyle = .long
            newDateFormatter.timeStyle = .none
            
            // Obtain newly formatted Date String as "Thursday, November 7, 2019"
            let dateWithFormat = newDateFormatter.string(from: dateStruct!)
            
            /* 
             =====================================================
             Create an instance of the ParkVisit Entity and dress it up
             =====================================================
            */
            // ❎ Create an instance of the ParkVisit entity in CoreData managedObjectContext
            let aPark = ParkVisit(context: self.managedObjectContext)
           
            // ❎ Dress it up by specifying its attributes
            aPark.dateVisited = dateWithFormat
            aPark.fullName = park.fullName
            aPark.rating = park.rating
            aPark.speechToTextNotes = park.speechToTextNotes
            aPark.states = park.states


            
            /*
             ==========================================================
             Create an instance of the Audio Entity and dress it up
             ==========================================================
            */
            // ❎ Create an instance of the Thumbnail Entity in CoreData managedObjectContext
            let aAudio = Audio(context: self.managedObjectContext)
            let audioUrl = Bundle.main.url(forResource: park.photoAndAudioFilename, withExtension: "m4a", subdirectory: "AudioFiles")
            
            do {
                aAudio.voiceRecording = try Data(contentsOf: audioUrl!, options: NSData.ReadingOptions.mappedIfSafe)
            }catch{
                print("Unable to create AVAudioPlayer!")
            }
            
            // ❎ Establish Relationship between entities Audio and ParkVisit
            aPark.audio = aAudio
            aAudio.parkVisit = aPark

            /*
            ==========================================================
            Create an instance of the Photo Entity and dress it up
            ==========================================================
             */
            // ❎ Create an instance of the Photo Entity in CoreData managedObjectContext
            let aPhoto = Photo(context: self.managedObjectContext)
            
            aPhoto.latitude = NSNumber(value: park.photoLatitude)
            aPhoto.longitude = NSNumber(value: park.photoLongitude)

            // Obtain the URL of the album cover photo filename from main bundle
            let photoUrl = Bundle.main.url(forResource: park.photoAndAudioFilename, withExtension: "jpg", subdirectory: "NationalParkPhotos")
            
            do {
                // Try to get the photo image data from imageUrl
                aPhoto.nationalParkPhoto = try Data(contentsOf: photoUrl!, options: NSData.ReadingOptions.mappedIfSafe)
                          
            } catch {
                fatalError("National park photo file is not found in the main bundle!")
            }
                       
            // ❎ Establish Relationship between entities Photo and ParkVisit
            aPark.photo = aPhoto
            aPhoto.parkVisit = aPark

            
            /*
             ==================================
             Save Changes to Core Data Database
             ==================================
            */
           
            // ❎ CoreData Save operation
            do {
                try self.managedObjectContext.save()
            } catch {
                return
            }
           
        }   // End of for loop
    }
 
}
 
struct ParksVisitedList_Previews: PreviewProvider {
    static var previews: some View {
        ParksVisitedList()
    }
}


