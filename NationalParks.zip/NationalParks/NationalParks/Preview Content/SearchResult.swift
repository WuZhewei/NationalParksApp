//
//  SearchResult.swift
//  NationalParks
//
//  Created by Zhewei Wu on 4/16/20.
//  Copyright © 2020 Zhewei Wu. All rights reserved.
//

import SwiftUI
import MapKit

struct SearchResult: View {
    var body: some View {
        Form {
            Group {
                
                Section(header: Text("National Park Full Name")) {
                    Text(verbatim: newNationalParkFound.fullName).bold().font(.system(size: 14))
                }
                
                Section(header: Text("States")) {
                    Text(verbatim: newNationalParkFound.states).bold().font(.system(size: 14))
                }
                
                Section(header: Text("National Park Decription")) {
                    Text(verbatim: newNationalParkFound.description).bold().font(.system(size: 13))
                }
                
                Section(header: Text("National Park Service Webpage")) {
                    NavigationLink(destination: WebView(url: newNationalParkFound.websiteUrl)) {
                        Image(systemName: "globe")
                            .foregroundColor(.black)
                            .imageScale(.medium)
                            .font(Font.title.weight(.regular))
                        Text("See National Park Service Webpage")
                            .font(.system(size: 14))
                            .foregroundColor(.black)
                            .bold()
                    }
                }
                
                Section(header: Text("National Park Location on Map")) {
                    NavigationLink(destination: parkMap) {
                        Image(systemName: "map.fill")
                    }
                }
                
                Section(header: Text("National Park Photos")) {
                    ForEach(0 ..< newNationalParkFound.images.count) { index in
                        VStack {
                            getImageFromUrl(url: newNationalParkFound.images[index].url)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: UIScreen.main.bounds.width - 30)

                            Text(newNationalParkFound.images[index].caption).bold().font(.system(size: 14))
                        }
                    }
                } // End of Section
                
            } // End of Group
        }   // End of Form
           .navigationBarTitle(Text("National Park Details"), displayMode: .inline)
    } // End of body
      
    var parkMap: some View {

        return AnyView(MapView(mapType: MKMapType.standard, latitude: newNationalParkFound.latitude, longitude: newNationalParkFound.longitude, delta: 100.0, deltaUnit: "meters", annotationTitle: newNationalParkFound.fullName, annotationSubtitle: newNationalParkFound.states)
                .navigationBarTitle(Text(verbatim: newNationalParkFound.fullName), displayMode: .inline)
                .edgesIgnoringSafeArea(.all))
    }
    
}

struct SearchResult_Previews: PreviewProvider {
    static var previews: some View {
        //SearchResult(nationalPark:listofNationalPark[0])
        SearchResult()
    }
}

