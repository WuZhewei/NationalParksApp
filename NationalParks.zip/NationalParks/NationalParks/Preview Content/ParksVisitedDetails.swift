//
//  ParksVisitedDetails.swift
//  NationalParks
//
//  Created by Zhewei Wu on 4/14/20.
//  Copyright © 2020 Zhewei Wu. All rights reserved.
//

import SwiftUI
import MapKit
import AVFoundation


struct ParksVisitedDetails: View {
    // ❎ Input parameter: CoreData Song Entity instance reference
    let park: ParkVisit
   
    // ❎ CoreData FetchRequest returning all Song entities in the database
    @FetchRequest(fetchRequest: ParkVisit.allParksFetchRequest()) var allParkss: FetchedResults<ParkVisit>
    
    // ❎ Refresh this view upon notification that the managedObjectContext completed a save.
    // Upon refresh, @FetchRequest is re-executed fetching all Song entities with all the changes.
    @EnvironmentObject var userData: UserData
    @EnvironmentObject var audioPlayer: AudioPlayer
   
    var body: some View {
        Form {
            
            /*
            ?? is called nil coalescing operator.
            IF song.albumName is not nil THEN
                unwrap it and return its value
            ELSE return ""
            */
            
            
            Section(header: Text("National Park Full Name")) {
                Text(park.fullName ?? "").bold()
            }
            
            Section(header: Text("States")) {
                Text(park.states ?? "").bold()
            }
            
            Section(header: Text("National Park Visit Photo")) {
                photoImageFromBinaryData(binaryData: park.photo!.nationalParkPhoto!)
                .resizable()
                .aspectRatio(contentMode: .fit)
            }
            
            Section(header: Text("Show Park Visit Photo Location on Map")) {
                NavigationLink(destination: locationMap) {
                    Image(systemName: "map.fill")
                }
            }
            
            Section(header: Text("Play Notes Taken by Voice Recording")) {
                   Button(action: {
                       if self.audioPlayer.isPlaying{
                          self.audioPlayer.pauseAudioPlayer()
                       }else{
                           self.audioPlayer.startAudioPlayer()
                       }
                   })
                   {
                       Image(systemName: self.audioPlayer.isPlaying ? "pause.fill" : "play.fill")
                           .foregroundColor(.blue)
                           .font(Font.title.weight(.regular))
                 }
            }

            
            Section(header: Text("Notes Taken by Speech to Text Conversion")) {
                Text(park.speechToTextNotes ?? "").bold()
            }
            
            Section(header: Text("Date Visited National Park")) {
                Text(park.dateVisited ?? "").bold()
            }
            
            Section(header: Text("My National Park Rating")) {
                Text(park.rating ?? "").bold()
                
            }
            
            
        }   // End of Form
        .navigationBarTitle(Text("National Park Details"), displayMode: .inline)
        .font(.system(size: 14))
        .onAppear() {
            self.createPlayer()
        }
        .onDisappear() {
            self.audioPlayer.stopAudioPlayer()
        }
    }   // End of body
    
    /*
    ---------------------------
    MARK: - Create Audio Player
    ---------------------------
    */
    func createPlayer() {
       
//        let filename = voiceMemo.id.uuidString + ".m4a"
//        let voiceMemoFileUrl = documentDirectory.appendingPathComponent(filename)
        let filename = self.park.audio!.voiceRecording!
        audioPlayer.createAudioPlayer(audioData: filename)
    }
        
        
    /*
    ---------------------------
    MARK: - Display Map
    ---------------------------
    */
    var locationMap: some View {
        return AnyView(MapView(mapType: MKMapType.standard, latitude: Double(truncating: self.park.photo!.latitude!), longitude: Double(truncating: self.park.photo!.longitude!), delta: 27.0, deltaUnit: "degrees", annotationTitle: self.park.fullName ?? "", annotationSubtitle: self.park.fullName ?? "")
                .navigationBarTitle(Text(verbatim: self.park.fullName ?? ""), displayMode: .inline)
                .edgesIgnoringSafeArea(.all) )
    }
    
    
}
 

