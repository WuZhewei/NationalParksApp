//
//  SearchByStateItem.swift
//  NationalParks
//
//  Created by Zhewei Wu on 4/17/20.
//  Copyright © 2020 Zhewei Wu. All rights reserved.
//

import SwiftUI

struct SearchByStateItem: View {

    let nationalPark: ParkStruct
    
    var body: some View {
        HStack {
            getImageFromUrl(url: nationalPark.images[0].url)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 80.0, height: 60.0)
           
            VStack(alignment: .leading) {
                Text(verbatim: nationalPark.fullName).bold()
                HStack {
                    Text(verbatim: nationalPark.states).bold()
                }
            }
            .font(.system(size: 14))
        } // End of HStack
    }
}

struct SearchByStateItem_Previews: PreviewProvider {
    static var previews: some View {
        SearchByStateItem(nationalPark: stateParkList[0])
    }
}
