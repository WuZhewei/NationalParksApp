//
//  ParksVisitedItem.swift
//  NationalParks
//
//  Created by Zhewei Wu on 4/14/20.
//  Copyright © 2020 Zhewei Wu. All rights reserved.
//

import SwiftUI
 
struct ParksVisitedItem: View {
    // ❎ Input parameter: CoreData Song Entity instance reference
    let park: ParkVisit
   
    // ❎ CoreData FetchRequest returning all Song entities in the database
    @FetchRequest(fetchRequest: ParkVisit.allParksFetchRequest()) var allParkss: FetchedResults<ParkVisit>
   
    // ❎ Refresh this view upon notification that the managedObjectContext completed a save.
    // Upon refresh, @FetchRequest is re-executed fetching all Song entities with all the changes.
    @EnvironmentObject var userData: UserData
   
    var body: some View {
        HStack {
            photoImageFromBinaryData(binaryData: park.photo!.nationalParkPhoto!)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 80.0, height: 60.0)
           
            VStack(alignment: .leading) {
                /*
                ?? is called nil coalescing operator.
                IF song.artistName is not nil THEN
                    unwrap it and return its value
                ELSE return ""
                */
                Text(park.fullName ?? "").bold()
                Text(park.dateVisited ?? "").bold()
                Text(park.rating ?? "").bold()
            }
            .font(.system(size: 14))
            
        }
    }
}

