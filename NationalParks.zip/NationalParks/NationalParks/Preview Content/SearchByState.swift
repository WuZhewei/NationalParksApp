//
//  SearchByState.swift
//  NationalParks
//
//  Created by Zhewei Wu on 4/17/20.
//  Copyright © 2020 Zhewei Wu. All rights reserved.
//

import SwiftUI

struct SearchByState: View {
    let usStates = ["Alabama (AL)", "Alaska (AK)", "Arizona (AZ)", "Arkansas (AR)", "California (CA)",
                    "Colorado (CO)", "Connecticut (CT)", "Delaware (DE)", "Florida (FL)", "Georgia (GA)",
                    "Hawaii (HI)", "Idaho (ID)", "Illinois (IL)", "Indiana (IN)", "Iowa (IA)",
                    "Kansas (KS)", "Kentucky (KY)", "Louisiana (LA)", "Maine (ME)", "Maryland (MD)",
                    "Massachusetts (MA)", "Michigan (MI)", "Minnesota (MN)", "Mississippi (MS)", "Missouri (MO)",
                    "Montana (MT)", "Nebraska (NE)", "Nevada (NV)", "New Hampshire (NH)", "New Jersey (NJ)",
                    "New Mexico (NM)", "New York (NY)", "North Carolina (NC)", "North Dakota (ND)", "Ohio (OH)",
                    "Oklahoma (OK)", "Oregon (OR)", "Pennsylvania (PA)", "Rhode Island (RI)", "South Carolina (SC)",
                    "South Dakota (SD)", "Tennessee (TN)", "Texas (TX)", "Utah (UT)", "Vermont (VT)",
                    "Virginia (VA)", "Washington (WA)", "West Virginia (WV)", "Wisconsin (WI)", "Wyoming (WY)"]
    
    @State var selectedIndexTousStates = 0
    @State private var searchCompleted = false
    @State private var searchFieldEmpty = false
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Select U.S. State to Search for National Parks")) {
                    Picker("Selected State:", selection: $selectedIndexTousStates) {
                        ForEach(0 ..< usStates.count, id: \.self) {
                            Text(self.usStates[$0])
                        }
                    }
                }
            
                Section(header: Text("Search National Parks in "+"\(self.usStates[selectedIndexTousStates])")) {
                    HStack {
                        Button(action: {
                            // Remove spaces, if any, at the beginning and at the end of the entered search query string
                            let queryTrimmed = self.usStates[self.selectedIndexTousStates]
                            
                            if (queryTrimmed.isEmpty) {
                                self.searchFieldEmpty = true
                            } else {
                                self.searchApi()
                                self.searchCompleted = true
                            }
                        }) {
                            Text(self.searchCompleted ? "Search Completed" : "Search")
                        }
                        .frame(width: UIScreen.main.bounds.width - 40, height: 36, alignment: .center)
                        .background(
                            RoundedRectangle(cornerRadius: 16)
                                .strokeBorder(Color.black, lineWidth: 1)
                        )
                    }   // End of HStack
                } // End of Section
                        
                if searchCompleted {
                    Section(header: Text("List National Parks in "+"\(self.usStates[selectedIndexTousStates])")) {
                        NavigationLink(destination: showSearchResults) {
                            Image(systemName: "list.bullet")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }
                }
            }   // End of Form
            .navigationBarTitle(Text("Search National Parks in a State"), displayMode: .inline)
        } // End of NavigationView
    } // End of Body
       
    func searchApi() {
        let array1 = self.usStates[self.selectedIndexTousStates].components(separatedBy: "(")
        let array2 = array1[1].components(separatedBy: ")")
        let stateIdFrom = array2[0]
        
        // public func obtainStateDataFromApi is given in CompanyDataFromApi.swift
        obtainStateDataFromApi(query: stateIdFrom)
    }
        
    var showSearchResults: some View {
        return AnyView(SearchByStateList()
            .navigationBarTitle(Text("National Parks in "+"\(self.usStates[selectedIndexTousStates])"), displayMode: .inline))
    }
} // End of Struct



struct SearchByState_Previews: PreviewProvider {
    static var previews: some View {
        SearchByState()
    }
}

