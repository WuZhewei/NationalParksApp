//
//  ParkStruct.swift
//  NationalParks
//
//  Created by Zhewei Wu on 4/14/20.
//  Copyright © 2020 Zhewei Wu. All rights reserved.
//

import Foundation

/* For Each will need parameter $id, so Identifiable is mandatory. */

struct ParkStruct: Hashable, Identifiable {
    
    var id : UUID
    var fullName: String
    var states: String
    var websiteUrl: String
    var latitude: Double
    var longitude: Double
    var description: String
    var images: [ParkPhoto]
}

struct ParkPhoto: Hashable {
    
    var url: String
    var caption: String
}
