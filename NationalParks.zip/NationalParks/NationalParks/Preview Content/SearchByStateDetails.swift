//
//  SearchByStateDetails.swift
//  NationalParks
//
//  Created by Zhewei Wu on 4/17/20.
//  Copyright © 2020 Zhewei Wu. All rights reserved.
//

import SwiftUI
import MapKit

struct SearchByStateDetails: View {
    // Input Parameter
    let nationalPark: ParkStruct
    
    var body: some View {
        Form {
            Group {
                Section(header: Text("National Park Full Name")) {
                    Text(verbatim: nationalPark.fullName).bold().font(.system(size: 14))
                }
                
                Section(header: Text("States")) {
                    Text(verbatim: nationalPark.states).bold().font(.system(size: 14))
                }
                
                Section(header: Text("National Park Decription")) {
                    Text(verbatim: nationalPark.description).bold().font(.system(size: 13))
                }
                
                Section(header: Text("National Park Service Webpage")) {
                    NavigationLink(destination: WebView(url: nationalPark.websiteUrl)) {
                        Image(systemName: "globe")
                            .foregroundColor(.black)
                            .imageScale(.medium)
                            .font(Font.title.weight(.regular))
                        Text("See National Park Service Webpage")
                             .font(.system(size: 14))
                             .foregroundColor(.black)
                             .bold()
                    }
                }
                
                Section(header: Text("National Park Location on Map")) {
                    NavigationLink(destination: parkMap) {
                        Image(systemName: "map.fill")
                    }
                }
                
                Section(header: Text("National Park Photos")) {
                    ForEach(0 ..< nationalPark.images.count) { index in
                        VStack {
                            getImageFromUrl(url: self.nationalPark.images[index].url)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: UIScreen.main.bounds.width - 30)
                                   
                            Text(self.nationalPark.images[index].caption).bold().font(.system(size: 14))
                        }
                    }
                }
            }
        }   // End of Form
        .navigationBarTitle(Text("National Park Details"), displayMode: .inline)
    }
      
    var parkMap: some View {

        return AnyView(MapView(mapType: MKMapType.standard, latitude: nationalPark.latitude, longitude: nationalPark.longitude, delta: 1300000.0, deltaUnit: "meters", annotationTitle: nationalPark.fullName, annotationSubtitle: nationalPark.states)
                .navigationBarTitle(Text(verbatim: nationalPark.fullName), displayMode: .inline)
                .edgesIgnoringSafeArea(.all))
    }
}

struct SearchByStateDetails_Previews: PreviewProvider {
    static var previews: some View {
        SearchByStateDetails(nationalPark:stateParkList[0])
    }
}

