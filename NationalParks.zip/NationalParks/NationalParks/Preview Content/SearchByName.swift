//
//  SearchByName.swift
//  NationalParks
//
//  Created by Zhewei Wu on 4/16/20.
//  Copyright © 2020 Zhewei Wu. All rights reserved.
//

import SwiftUI

struct SearchByName: View {
    @State private var searchStringEntered = ""
    @State private var searchTextFieldValue = ""
      
    var body: some View {
          
        NavigationView {
            Form {
                Section(header: Text("Enter national park full name to search for"))
                {
                    HStack {
                        /*
                        🔴 When the user enters a character in the TextField,
                        searchTextFieldValue changes upon which the body View is refreshed.
                        When the user hits Return on keyboard, the entire search string is
                        put into searchStringEntered upon which the body View is refreshed.
                        */
                        TextField("Enter national park full name", text: $searchTextFieldValue,
                            onCommit: {
                                // Record entered value after Return key is pressed
                                self.searchStringEntered = self.searchTextFieldValue}
                        ) // End of TextField
    
                        // Keyboard Types: .decimalPad, .default, .emailAddress,
                        // .namePhonePad, .numberPad, .numbersAndPunctuation
                        .keyboardType(.default)
    
                        // Turn off auto correction
                        .disableAutocorrection(true)
                          
                        // Button to clear the text field
                        Button(action: {
                            self.searchTextFieldValue = ""
                            self.searchStringEntered = ""
                        }) {
                            Image(systemName: "multiply.circle")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }   // End of HStack
                }   // End of Section
                  
                // Show this section only after Return key is pressed
                if !searchStringEntered.isEmpty {
                    Section(header: Text("List Details of \(self.searchStringEntered)")) {
                        NavigationLink(destination: searchNationalPark) {
                            Image(systemName: "list.bullet")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }
                }
            }   // End of Form
            .navigationBarTitle(Text("Search a National Park"), displayMode: .inline)
            
        }   // End of NavigationView
    }
      
    var searchNationalPark: some View {
        // Remove spaces, if any, at the beginning and at the end of the entered search query string
        let searchStringTrimmed = searchStringEntered.trimmingCharacters(in: .whitespacesAndNewlines)
        let searchQuery = searchStringTrimmed.capitalized
        
        // public function obtainNationalParkDataFromApi is given in CountryApiData.swift
        obtainNationalParkDataFromApi(query: searchQuery)
        
        return AnyView(SearchResult())
    }
}

struct SearchByName_Previews: PreviewProvider {
    static var previews: some View {
        SearchByName()
    }
}

