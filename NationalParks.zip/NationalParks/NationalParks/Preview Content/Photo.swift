//
//  Photo.swift
//  NationalParks
//
//  Created by Zhewei Wu on 4/14/20.
//  Copyright © 2020 Zhewei Wu. All rights reserved.
//

import Foundation
import CoreData
 
 
// ❎ CoreData Photo entity public class
public class Photo: NSManagedObject, Identifiable {
 
    @NSManaged public var dateTime: String?
    @NSManaged public var latitude: NSNumber?
    @NSManaged public var longitude: NSNumber?
    @NSManaged public var nationalParkPhoto: Data?
    @NSManaged public var parkVisit: ParkVisit?
}
