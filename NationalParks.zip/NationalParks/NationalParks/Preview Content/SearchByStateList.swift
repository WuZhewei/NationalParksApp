//
//  SearchByStateList.swift
//  NationalParks
//
//  Created by Zhewei Wu on 4/17/20.
//  Copyright © 2020 Zhewei Wu. All rights reserved.
//

import SwiftUI

struct SearchByStateList: View {
    @EnvironmentObject var userData: UserData
    
    var body: some View {
        List {
            ForEach(stateParkList) { aPark in
                NavigationLink(destination: SearchByStateDetails(nationalPark: aPark)) {
                    SearchByStateItem(nationalPark: aPark)
                }
            }
        } // End of List
    } // End of Body
} // End of Struct

struct SearchByStateList_Previews: PreviewProvider {
    static var previews: some View {
        SearchByStateList()
    }
}

