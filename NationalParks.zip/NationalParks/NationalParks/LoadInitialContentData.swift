//
//  LoadInitialContentData.swift
//  NationalParks
//
//  Created by Zhewei Wu on 4/14/20.
//  Copyright © 2020 Zhewei Wu. All rights reserved.
//

import Foundation
import CoreLocation
import AVFoundation
 
// Global array of Park structs
var listOfNationalParks = [NationalPark]()
let locationManager = CLLocationManager()

// Global Variables
var audioSession:   AVAudioSession!
var audioRecorder:  AVAudioRecorder!

let documentDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]

/*
 *************************************
 MARK: - Load Initial Database Content
 *************************************
 */
public func loadInitialDatabaseContent() {
 
    listOfNationalParks = loadFromMainBundle("InitialDatabaseContent.json")
}
 
/*
****************************************************
MARK: - Get JSON File from Main Bundle and Decode it
****************************************************
*/
func loadFromMainBundle<T: Decodable>(_ filename: String, as type: T.Type = T.self) -> T {
    let data: Data
   
    guard let file = Bundle.main.url(forResource: filename, withExtension: nil)
        else {
            fatalError("Unable to find \(filename) in main bundle.")
    }
   
    do {
        data = try Data(contentsOf: file)
    } catch {
        fatalError("Unable to load \(filename) from main bundle:\n\(error)")
    }
   
    do {
        let decoder = JSONDecoder()
        return try decoder.decode(T.self, from: data)
    } catch {
        fatalError("Unable to parse \(filename) as \(T.self):\n\(error)")
    }
}


/*
  ==================================================
  |   Get User's Permission for Current Location   |
  ==================================================
 */
 public func getPermissionForLocation() {
     /*
      We need to obtain the user's permission to access his/her location much before we need it.
      Doing this in the currentLocation() function below would be too late since it will not be
      recorded in time to allow access when the function executes. Therefore, we call this
      function from AppDelegate upon app launch and do it here.
     */
     locationManager.requestWhenInUseAuthorization()
   
     // Another option: locationManager.requestAlwaysAuthorization()
 }
  
 /*
  ============================================================
  |   Obtain and Return User's Current Location Coordinate   |
  ============================================================
 */
 public func currentLocation() -> CLLocationCoordinate2D {
     /*
      🔴 Current GPS location cannot be accurately determined under the iOS Simulator
         on your laptop or desktop computer because those computers do NOT have a GPS antenna.
         Therefore, do NOT expect the code herein to work under the iOS Simulator!
    
      You must deploy your location-aware app to an iOS device to be able to test it properly.
  
      Monitoring the user's current location is a serious privacy issue!
      🔴 Set one of the "Privacy - Location ..." keys in the Info.plist
         to display an alert message asking for user's permission.
      */
  
     // Instantiate a CLLocationCoordinate2D object with initial values
     var currentLocationCoordinate = CLLocationCoordinate2D(latitude: 0.0, longitude: 0.0)
  
     /*
      The user can turn off location services on an iOS device in Settings.
      First, you must check to see of it is turned off or not.
      */
     if CLLocationManager.locationServicesEnabled() {
              
         // Set up locationManager
         locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
         locationManager.startUpdatingLocation()
      
         // Ask locationManager to obtain the user's current location coordinate
         if let location = locationManager.location {
             currentLocationCoordinate = location.coordinate
         } else {
             print("Unable to obtain user's current location")
         }
      
     } else {
         // Location Services turned off in Settings
     }
    
     // Stop updating location when not needed to save battery of the device
     locationManager.stopUpdatingLocation()
  
     return currentLocationCoordinate
 }

public func getPermissionForVoiceRecording() {
   
    // Create the shared audio session instance
    audioSession = AVAudioSession.sharedInstance()
   
    do {
        // Set audio session category to record and play back audio
        try audioSession.setCategory(.playAndRecord, mode: .default)
       
        // Activate the audio session
        try audioSession.setActive(true)
       
        // Request permission to record user's voice
        audioSession.requestRecordPermission() { allowed in
            DispatchQueue.main.async {
                if allowed {
                    // Permission is recorded in the Settings app on user's device
                } else {
                    // Permission is recorded in the Settings app on user's device
                }
            }
        }
    } catch {
        print("Setting category or getting permission failed!")
    }
}
