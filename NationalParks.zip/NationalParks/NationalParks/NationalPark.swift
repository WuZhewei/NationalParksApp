//
//  NationalPark.swift
//  NationalParks
//
//  Created by Zhewei Wu on 4/14/20.
//  Copyright © 2020 Zhewei Wu. All rights reserved.
//

import Foundation
 
struct NationalPark: Hashable, Codable { // Hashable
   
    var photoAndAudioFilename: String
    var fullName: String
    var states: String
    var dateVisited: String
    var photoDateTime: String
    var photoLatitude: Double
    var photoLongitude: Double
    var speechToTextNotes: String
    var rating: String
}

//"photoAndAudioFilename": "Acadia",
//"fullName": "Acadia National Park",
//"states": "Maine",
//"dateVisited": "2019-07-24",
//"photoDateTime": "2019-07-24 at 14:35:12",
//"photoLatitude": 44.338554,
//"photoLongitude": -68.273338,
//"speechToTextNotes": "Acadia National Park is like no other place on Earth, people will tell you. From its mountaintops of rosy granite to its cobblestone beaches, everywhere you turn, you find beauty.",
//"rating": "Excellent"
